#!/usr/bin/env sh
set -e

echo "Entrypoint: cwd = $(pwd)"
echo "Conteúdo de $(pwd):"
ls -al

echo "⏳ Aguardando o banco iniciar em db:5432..."
while ! nc -z db 5432; do
  sleep 1
done

echo "✅ Banco de dados pronto. Aplicando migrações…"
python manage.py migrate --noinput

echo "🗃️  Coletando arquivos estáticos…"
python manage.py collectstatic --noinput

echo "🚀 Iniciando o Gunicorn…"
/usr/local/bin/gunicorn sistema.wsgi:application --bind 0.0.0.0:8000