
import json, os, socket
import pandas as pd
from sqlalchemy import create_engine
from dotenv import load_dotenv

# 📦 Carregar variáveis do .env
base_dir = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(base_dir, "..", "..", ".env"))

DB_NAME = os.getenv("db_name")
DB_USER = os.getenv("db_user")
DB_PASSWORD = os.getenv("db_password")
DB_HOST = "localhost"                 #"os.getenv("db_host")"
DB_PORT = os.getenv("db_port")

# Fallback para localhost se necessário
if DB_HOST == "db":
    try:
        socket.gethostbyname("db")
    except socket.gaierror:
        DB_HOST = "localhost"

DATABASE_URL = f"postgresql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(DATABASE_URL)

# 📁 Caminho do JSON
INPUT_JSON = os.path.join(base_dir, "..", "data", "monday_export_all.json")

# 1️⃣ Carregar JSON
with open(INPUT_JSON, "r", encoding="utf-8") as f:
    data = json.load(f)

# 2️⃣ Converter para DataFrame
records = []
for item in data["items"]:
    record = {
        "Item ID": item["id"],
        "Name": item["name"]
    }
    for col in item["column_values"]:
        record[col["id"]] = col["text"]
    records.append(record)
df = pd.DataFrame(records)
df["last_updated"] = df.get("due_date", "").astype(str)
df["Item ID"] = df["Item ID"].astype(str)

# Histórico mock
with engine.connect() as conn:
    historico_db = pd.read_sql("""
        SELECT id_monday AS "Item ID", 
       TO_CHAR(last_updated, 'YYYY-MM-DD HH24:MI:SS') AS "last_updated"
        FROM repairs
    """, conn)
historico_db["last_updated"] = historico_db["last_updated"].astype(str)
historico_db["Item ID"] = historico_db["Item ID"].astype(str)

# Filtrar dados novos
novos_dados = df.merge(
    historico_db,
    how="left",
    left_on=["Item ID", "last_updated"],
    right_on=["Item ID", "last_updated"],
    indicator=True
)
novos_dados = novos_dados[novos_dados["_merge"] == "left_only"].drop(columns=["_merge"])

# Normalizar cliente
def normalizar_cliente_rigido(texto):
    import unicodedata, re
    if pd.isna(texto): return ""
    texto = unicodedata.normalize('NFKD', texto).encode('ASCII', 'ignore').decode('utf-8')
    texto = texto.upper()
    texto = re.sub(r'\s+', '', texto)
    texto = texto.replace('-', '')
    return texto

novos_dados["cliente_normalizado"] = novos_dados["cliente"].apply(normalizar_cliente_rigido)

# 6️⃣ Inserir CLIENTES
clients_df = novos_dados.sort_values("cliente").drop_duplicates(subset="cliente_normalizado")
clients_df = clients_df.rename(columns={"cliente": "name_client"})[["name_client"]]
clients_df = clients_df[clients_df["name_client"].notna() & (clients_df["name_client"].str.strip() != "")]
clients_df.to_sql("clients", engine, if_exists="append", index=False)

with engine.connect() as conn:
    client_map = pd.read_sql("SELECT id_client, name_client FROM clients", conn)

# 7️⃣ Inserir PARTS
parts_df = novos_dados[["text", "Name", "texto__1", "texto8__1", "cliente"]].drop_duplicates()
parts_df = parts_df.rename(columns={
    "text": "num_serie",
    "Name": "model",
    "texto__1": "machine",
    "texto8__1": "sid"
})
parts_df = parts_df[parts_df["num_serie"].notna() & (parts_df["num_serie"].str.strip() != "")]
parts_df["model_len"] = parts_df["model"].str.len()
parts_df = parts_df.sort_values("model_len").drop_duplicates(subset="num_serie", keep="first")
parts_df = parts_df.drop(columns=["model_len"])

parts_df = parts_df.merge(client_map, how="left", left_on="cliente", right_on="name_client")
parts_df = parts_df.drop(columns=["cliente", "name_client"])

# 🔎 Remover num_serie que já existem no banco
with engine.connect() as conn:
    existentes = pd.read_sql("SELECT num_serie FROM parts", conn)
parts_df = parts_df[~parts_df["num_serie"].isin(existentes["num_serie"])]
parts_df.to_sql("parts", engine, if_exists="append", index=False)

with engine.connect() as conn:
    part_map = pd.read_sql("SELECT id_part, num_serie FROM parts", conn)

# 8️⃣ Montar e inserir REPAIRS
repairs_df = novos_dados.merge(client_map, how="left", left_on="cliente", right_on="name_client")
repairs_df = repairs_df.merge(part_map, how="left", left_on="text", right_on="num_serie")

repairs_df = repairs_df.rename(columns={
    "Item ID": "id_monday",
    "proposta_n_": "proposal_no",
    "status_1": "priority",
    "status": "status",
    "due_date": "submit_date",
    "date": "resolved_at",
    "time_tracking": "mttr",
    "person4": "owner",
    "n_meros6__1": "num_tests",
    "n_meros__1": "num_returns",
    "duration_mkrj314b": "testing",
    "duration_mkre9emh": "purchasing",
    "duration_mkre259m": "printing",
    "last_updated": "last_updated"
})[[
    "id_client", "id_part", "id_monday", "proposal_no", "priority", "status",
    "submit_date", "resolved_at", "mttr", "owner", "num_tests", "num_returns",
    "testing", "purchasing", "printing", "last_updated"
]]


# 🔧 Corrigir formatos inválidos
repairs_df['submit_date'] = pd.to_datetime(repairs_df['submit_date'], errors='coerce')
repairs_df['resolved_at'] = pd.to_datetime(repairs_df['resolved_at'], errors='coerce')
repairs_df['mttr'] = pd.to_timedelta(repairs_df['mttr'], errors='coerce')
repairs_df['mttr'] = pd.to_timedelta(repairs_df['mttr'], errors='coerce')
repairs_df['mttr'] = repairs_df['mttr'].apply(lambda x: str(x).split(' ')[-1] if pd.notnull(x) else None)

# 🔧 Corrigir campos inteiros que vieram como string vazia
for col in ["num_tests", "num_returns"]:
    repairs_df[col] = pd.to_numeric(repairs_df[col], errors="coerce")
repairs_df.to_sql("repairs", engine, if_exists="append", index=False)

print("✅ Dados salvos no PostgreSQL com sucesso!")
