import os
from datetime import datetime, timedelta
import pandas as pd
from sqlalchemy import create_engine, text
from dotenv import load_dotenv


def load_database():
    """Carrega engine do banco de dados usando .env."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    load_dotenv(os.path.join(base_dir, "..", "..", ".env"))
    db_url = f"postgresql://{os.getenv('db_user')}:{os.getenv('db_password')}@" \
             f"localhost:{os.getenv('db_port')}/{os.getenv('db_name')}"
    return create_engine(db_url)


def get_week_range(start_date, end_date):
    """Gera intervalos semanais entre duas datas."""
    start_monday = start_date - timedelta(days=start_date.weekday())
    current = start_monday
    while current <= end_date:
        yield current, current + timedelta(days=6)
        current += timedelta(weeks=1)


def kpi_exists(engine, kpi_name, referente, captured_at):
    """Verifica se já existe KPI registrado para o período."""
    query = text("""
        SELECT 1 FROM kpi_records
        WHERE kpi_name = :kpi
        AND referente = :referente
        AND captured_at = :captured
        LIMIT 1
    """)
    with engine.connect() as conn:
        result = conn.execute(query, {
            "kpi": kpi_name,
            "referente": referente,
            "captured": captured_at
        })
        return result.scalar() is not None


def insert_kpi(engine, kpi_name, kpi_value, referente, start_date):
    """Insere KPI no banco de dados."""
    captured = start_date.strftime("%Y") + "-" + start_date.strftime("%V")
    df = pd.DataFrame([{
        "kpi_name": kpi_name,
        "kpi_value": kpi_value,
        "referente": referente,
        "referente_id": None,
        "periodicity": "WEEKLY",
        "captured_at": captured
    }])
    df.to_sql("kpi_records", engine, if_exists="append", index=False)


def calculate_tr(df, start_date, end_date):
    """Calcula Throughput Rate (TR)."""
    start_date = datetime.combine(start_date, datetime.min.time())
    end_date = datetime.combine(end_date, datetime.max.time())
    entradas = df[
        (df["submit_date"] >= start_date) & (df["submit_date"] <= end_date)
    ].shape[0]
    saidas = df[
        (df["resolved_at"] >= start_date) & (df["resolved_at"] <= end_date)
    ].shape[0]
    
    tr = None
    if ((entradas != 0) and (saidas != 0)):
        tr = round(saidas / entradas, 4)
    else:
        if (entradas == 0):
            tr = saidas
        if (saidas == 0):
            tr = -entradas
    return tr


def main():
    """Executa cálculo semanal de KPIs."""
    engine = load_database()
    referente = "LAB"
    kpi_name = "TR"

    with engine.connect() as conn:
        repairs_df = pd.read_sql("SELECT * FROM repairs", conn)
    repairs_df["submit_date"] = pd.to_datetime(repairs_df["submit_date"], errors="coerce")
    repairs_df["resolved_at"] = pd.to_datetime(repairs_df["resolved_at"], errors="coerce")

    min_date = repairs_df["submit_date"].min().date()
    today = datetime.now().date()

    for start_week, end_week in get_week_range(min_date, today):
        captured = start_week.strftime("%Y") + "-" + start_week.strftime("%V")
        if not kpi_exists(engine, kpi_name, referente, captured):
            tr_value = calculate_tr(repairs_df, start_week, end_week)
            if tr_value is not None:
                insert_kpi(engine, kpi_name, tr_value, referente, start_week)
                print(f"✅ {kpi_name} calculado para semana {captured}: {tr_value}")
            else:
                print(f"⚠️ Nenhuma entrada na semana {captured}, {kpi_name} não calculado.")
        else:
            print(f"⏭️ {kpi_name} já registrado para semana {captured}")


if __name__ == "__main__":
    main()
