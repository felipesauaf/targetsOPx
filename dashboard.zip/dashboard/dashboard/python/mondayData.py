import pandas as pd
import datetime
import numpy as np

excel_path = 'data.xlsx'
df_lab = pd.read_excel(excel_path, sheet_name="laboratório - bancada")

# Construção do dicionário como antes
repairData = {"ELEMENT": [], "ID":[], "ORDER": [], "SN": [], "PRIORITY": [], "OWNER": [], "CLIENT": [], "SUBMIT": [], 
              "SOLVED": [], "MACHINE": [], "SID": [], "MTTR": [], "NUM_TESTS": []}

flag_start = 0
for idx, name in enumerate(df_lab.iloc[:, 0]):
    if flag_start:
        try:
            if (len(str(df_lab.iloc[idx, 0])) >= 3):
                repairData["ELEMENT"].append(str(df_lab.iloc[idx, 0]))
                repairData["ID"].append(df_lab.iloc[idx, 22])
                repairData["ORDER"].append(df_lab.iloc[idx, 1])
                repairData["SN"].append(df_lab.iloc[idx, 2])
                repairData["PRIORITY"].append(df_lab.iloc[idx, 3])
                repairData["OWNER"].append(df_lab.iloc[idx, 5])
                repairData["CLIENT"].append(df_lab.iloc[idx, 6])
                
                valor_submit = df_lab.iloc[idx, 8]
                if pd.notna(valor_submit):
                    if isinstance(valor_submit, (pd.Timestamp, datetime.datetime)):
                        valor_submit = valor_submit.strftime('%d/%m/%Y')
                    else:
                        valor_submit = str(valor_submit)
                else:
                    valor_submit = ""
                repairData["SUBMIT"].append(valor_submit)

                valor_solved = df_lab.iloc[idx, 9]
                if pd.notna(valor_solved):
                    if isinstance(valor_solved, (pd.Timestamp, datetime.datetime)):
                        valor_solved = valor_solved.strftime('%d/%m/%Y')
                    else:
                        valor_solved = str(valor_solved)
                else:
                    valor_solved = ""
                repairData["SOLVED"].append(valor_solved)
                
                repairData["MACHINE"].append(df_lab.iloc[idx, 10])
                repairData["SID"].append(df_lab.iloc[idx, 11])
                repairData["NUM_TESTS"].append(df_lab.iloc[idx, 12])
                repairData["MTTR"].append(df_lab.iloc[idx, 14])
        except Exception as e:
            print(f"Erro na linha {idx}: {e}")

    if ((name != None) and (flag_start != 1)):
        if (str(name) == "Name"):
            flag_start = 1

# Crie um DataFrame pandas com repairData
df = pd.DataFrame(repairData)

# Remova linhas sem data de SUBMIT válida
df = df[df['SUBMIT'] != '']
df = df[df['SOLVED'] != '']

# Converta SUBMIT para datetime (ignorar erros para datas ruins)
df['SUBMIT_DT'] = pd.to_datetime(df['SUBMIT'], format='%d/%m/%Y', errors='coerce')
df = df[df['SUBMIT_DT'].notna()]  # Mantém só datas válidas
df['SOLVED_DT'] = pd.to_datetime(df['SOLVED'], format='%d/%m/%Y', errors='coerce')
df = df[df['SOLVED_DT'].notna()]  # Mantém só datas válidas

# Adicione colunas de ano, semana e mês
df['Ano_entry'] = df['SUBMIT_DT'].dt.year
df['Semana_entry'] = df['SUBMIT_DT'].dt.isocalendar().week
df['Mes_entry'] = df['SUBMIT_DT'].dt.month
df['Ano_exit'] = df['SOLVED_DT'].dt.year
df['Semana_exit'] = df['SOLVED_DT'].dt.isocalendar().week
df['Mes_exit'] = df['SOLVED_DT'].dt.month

# Agrupe e conte por semana/ano
entries_semana = df.groupby(['Ano_entry', 'Semana_entry']).size().reset_index(name='Num_entries')
#print("\n=== Entradas por Semana_entry e Ano_entry ===")
#print(entries_semana)

# Agrupe e conte por mês/Ano_entry
entries_mes = df.groupby(['Ano_entry', 'Mes_entry']).size().reset_index(name='Num_entries')
#print("\n=== Entradas por Mês e Ano_entry ===")
#print(entries_mes)

# Agrupe e conte por semana/ano
exits_semana = df.groupby(['Ano_exit', 'Semana_exit']).size().reset_index(name='Num_entries')
#print("\n=== Entradas por Semana_exit e Ano_exit ===")
#print(entries_semana)

# Agrupe e conte por mês/ano
exits_mes = df.groupby(['Ano_exit', 'Mes_exit']).size().reset_index(name='Num_exits')
#print("\n=== Saídas por Mês e Ano ===")
#print(exits_mes)

# Agrupa entradas por semana/ano
entries_semana = df.groupby(['Ano_entry', 'Semana_entry']).size().reset_index(name='Num_entries')
# Agrupa saídas por semana/ano
exits_semana = df.groupby(['Ano_exit', 'Semana_exit']).size().reset_index(name='Num_exits')


# Merge para criar tabela única com ambas as informações
vazao_semana = pd.merge(
    entries_semana,
    exits_semana,
    left_on=['Ano_entry', 'Semana_entry'],
    right_on=['Ano_exit', 'Semana_exit'],
    how='outer'
).fillna(0)

# Ajuste de Ano e Semana para sempre mostrar o correto
vazao_semana['Ano_final'] = np.where(
    vazao_semana['Ano_entry'] != 0,
    vazao_semana['Ano_entry'],
    vazao_semana['Ano_exit']
)
vazao_semana['Semana_final'] = np.where(
    vazao_semana['Semana_entry'] != 0,
    vazao_semana['Semana_entry'],
    vazao_semana['Semana_exit']
)

# Agora reorganize as colunas
vazao_semana = vazao_semana.rename(columns={
    'Num_entries': 'Num_entries',
    'Num_exits': 'Num_exits'
})[['Ano_final', 'Semana_final', 'Num_entries', 'Num_exits']]

vazao_semana = vazao_semana.rename(columns={
    'Ano_final': 'Ano',
    'Semana_final': 'Semana'
}).astype({'Ano': int, 'Semana': int, 'Num_entries': int, 'Num_exits': int})

#print('\n=== Vazão do laboratório por semana/ano (ajustado) ===')
#print(vazao_semana)


#print('\n=== Vazão do laboratório por semana/ano ===')
#print(vazao_semana)

elementos_por_ano = df.groupby('Ano_entry')['SN'].apply(list).reset_index()
#print(elementos_por_ano)

# Supondo que você já tem a coluna 'Ano_entry' (do SUBMIT)
num_reparos_ano = df.groupby('Ano_entry').size().reset_index(name='Num_reparos')
#print(num_reparos_ano)

# Conta o número de saídas agrupando por ano, semana e OWNER
exits_semana_owner = (
    df.groupby(['Ano_exit', 'Semana_exit', 'OWNER'])
      .size()
      .reset_index(name='Num_exits')
      .sort_values(['Ano_exit', 'Semana_exit', 'OWNER'])
)

#print(exits_semana_owner)

# Calcula o TAT em dias
df['TAT_dias'] = (df['SOLVED_DT'] - df['SUBMIT_DT']).dt.days

# Seleciona as colunas desejadas
kpi_tat = df[['ELEMENT', 'SN', 'OWNER', 'Ano_entry', 'Ano_exit', 'TAT_dias']].copy()

#print(kpi_tat)

# Tabela de Repeat Testing Rate (RTR)
kpi_rtr = df[['ELEMENT', 'SN', 'OWNER', 'Ano_entry', 'Ano_exit', 'NUM_TESTS']].copy()

#print(kpi_rtr)

with pd.ExcelWriter('base_kpis_lab.xlsx') as writer:
    entries_semana.to_excel(writer, sheet_name='Entradas_Semana', index=False)
    entries_mes.to_excel(writer, sheet_name='Entradas_Mes', index=False)
    exits_semana.to_excel(writer, sheet_name='Saidas_Semana', index=False)
    exits_mes.to_excel(writer, sheet_name='Saidas_Mes', index=False)
    vazao_semana.to_excel(writer, sheet_name='Vazao_Semana', index=False)
    exits_semana_owner.to_excel(writer, sheet_name='Saidas_Semana_OWNER', index=False)
    kpi_tat.to_excel(writer, sheet_name='TAT', index=False)
    kpi_rtr.to_excel(writer, sheet_name='RTR', index=False)


# 1.1. Seleciona as colunas relevantes e ordena por SN e SUBMIT
tabela_conferencia = df[['ELEMENT', 'SN', 'SUBMIT_DT', 'SOLVED_DT']].copy()
tabela_conferencia = tabela_conferencia.sort_values(['SN', 'SUBMIT_DT']).reset_index(drop=True)

# 1.2. Salva no Excel
with pd.ExcelWriter('base_kpis_lab.xlsx', mode='a', if_sheet_exists='replace') as writer:
    tabela_conferencia.to_excel(writer, sheet_name='Conferencia_MTBF', index=False)

# 2.1. Para cada SN, pega o nome mais curto associado
def nome_mais_curto(nomes):
    return min(nomes, key=len)

# 2.2. Cria um DataFrame agrupado por SN com a lista de ELEMENTs e o nome mais curto
agrupado = (
    tabela_conferencia.groupby('SN')
    .agg(
        ELEMENTS=('ELEMENT', list),
        NOME_CURTO=('ELEMENT', nome_mais_curto),
        SUBMITS=('SUBMIT_DT', list),
        SOLVEDS=('SOLVED_DT', list),
        NUM_MANUTENCOES=('ELEMENT', 'count')
    )
    .reset_index()
)

# 3.1. Função para verificar sobreposição de manutenções em um SN
def tem_sobreposicao(submits, solveds):
    for i in range(1, len(submits)):
        if submits[i] < solveds[i-1]:
            return True
    return False

# 3.2. Aplica a função e filtra só os SNs **sem sobreposição**
agrupado['SOBREPOSICAO'] = agrupado.apply(
    lambda row: tem_sobreposicao(row['SUBMITS'], row['SOLVEDS']), axis=1
)
agrupado_filtrado = agrupado[~agrupado['SOBREPOSICAO']].copy()

# 4.1. Função para calcular intervalos válidos de MTBF
def calc_mtbf(submits, solveds):
    if len(submits) < 2:
        return None
    intervalos = []
    for i in range(1, len(submits)):
        intervalos.append((submits[i] - solveds[i-1]).days)
    return sum(intervalos) / len(intervalos) if intervalos else None

agrupado_filtrado['MTBF'] = agrupado_filtrado.apply(
    lambda row: calc_mtbf(row['SUBMITS'], row['SOLVEDS']), axis=1
)

# 4.2. Seleciona colunas finais (NOME_CURTO, SN, NUM_MANUTENCOES, MTBF)
mtbf_final = agrupado_filtrado[['NOME_CURTO', 'SN', 'NUM_MANUTENCOES', 'MTBF']].copy()
mtbf_final = mtbf_final.rename(columns={'NOME_CURTO': 'NOME'})
# Filtra e imprime apenas os SNs com MTBF válido
mtbf_validos = mtbf_final[mtbf_final['MTBF'].notna()]

# 4.3. Salva a tabela de MTBF no Excel
with pd.ExcelWriter('base_kpis_lab.xlsx', mode='a', if_sheet_exists='replace') as writer:
    mtbf_validos.to_excel(writer, sheet_name='MTBF', index=False)

df['Repair_Efficiency'] = 1 / df['NUM_TESTS']

re_semana = (
    df.groupby(['Ano_exit', 'Semana_exit'])
      .agg(
          Repair_Efficiency=('Repair_Efficiency', 'mean'),
          Total_Reparos=('SN', 'count')
      )
      .reset_index()
      .sort_values(['Ano_exit', 'Semana_exit'])
)

with pd.ExcelWriter('base_kpis_lab.xlsx', mode='a', if_sheet_exists='replace') as writer:
    re_semana.to_excel(writer, sheet_name='Repair_Eff_Semana', index=False)

repair_efficiency_owner_semana = (
    df.groupby(['Ano_exit', 'Semana_exit', 'OWNER'])
      .agg(
          Repair_Efficiency=('Repair_Efficiency', 'mean'),
          Total_Reparos=('SN', 'count')
      )
      .reset_index()
      .sort_values(['Ano_exit', 'Semana_exit', 'OWNER'])
)

#print(repair_efficiency_owner_semana)

# Salva no Excel
with pd.ExcelWriter('base_kpis_lab.xlsx', mode='a', if_sheet_exists='replace') as writer:
    repair_efficiency_owner_semana.to_excel(writer, sheet_name='Repair_Efficiency_OWNER_Semana', index=False)


# 1. Crie a coluna que indica se passou de primeira
df['FIRST_PASS'] = df['NUM_TESTS'] == 1

# 2. Agrupe por ano e semana de saída, contando total e aprovados de primeira
fpy_semana = (
    df.groupby(['Ano_exit', 'Semana_exit'])
      .agg(
          Total_Reparos=('SN', 'count'),
          FirstPass=('FIRST_PASS', 'sum')
      )
      .assign(FPY=lambda x: (x['FirstPass'] / x['Total_Reparos']).round(4))
      .reset_index()
      .sort_values(['Ano_exit', 'Semana_exit'])
)

#print(fpy_semana)

# 3. Salve no Excel
with pd.ExcelWriter('base_kpis_lab.xlsx', mode='a', if_sheet_exists='replace') as writer:
    fpy_semana.to_excel(writer, sheet_name='FPY_Semana', index=False)


