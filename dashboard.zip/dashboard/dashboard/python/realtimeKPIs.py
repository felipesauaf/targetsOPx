import os
import numpy as np
import pandas as pd
from datetime import datetime
from sqlalchemy import create_engine, text
from dotenv import load_dotenv

# Carregar variáveis de ambiente
base_dir = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(base_dir, "..", "..", ".env"))

DB_NAME = os.getenv("db_name")
DB_USER = os.getenv("db_user")
DB_PASSWORD = os.getenv("db_password")
DB_HOST = "localhost"
DB_PORT = int(os.getenv("db_port"))

# Conexão
engine = create_engine(
    f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
)

# ===================== FUNÇÕES UTILITÁRIAS =====================

def insert_kpi_record(name, value, referente, referente_id, captured_at):
    """Insere um novo registro de KPI no banco."""
    with engine.connect() as conn:
        conn.execute(text("""
            INSERT INTO kpi_records (
                kpi_name, kpi_value, referente, referente_id,
                periodicity, captured_at
            )
            VALUES (
                :kpi_name, :kpi_value, :referente, :referente_id,
                'REALTIME', :captured_at
            )
        """), {
            "kpi_name": name,
            "kpi_value": float(value),
            "referente": referente,
            "referente_id": referente_id,
            "captured_at": captured_at
        })

def get_last_capture(kpi_name):
    """Retorna o último timestamp salvo para o KPI."""
    with engine.connect() as conn:
        result = conn.execute(text("""
            SELECT MAX(captured_at)
            FROM kpi_records
            WHERE kpi_name = :kpi_name AND periodicity = 'REALTIME'
        """), {"kpi_name": kpi_name})
        last = result.scalar()
    return datetime.strptime(last, "%Y-%W-%d-%H-%M-%S") if last else datetime(2000, 1, 1)

def registrar_kpis_por_grupo(grupo, kpi_name, coluna_valor, captured_at):
    """Insere os KPIs CLIENT, PART e LAB agrupados."""
    if "id_client" in grupo.columns:
        for client_id, g in grupo.groupby("id_client"):
            media = round(g[coluna_valor].mean(), 2)
            insert_kpi_record(kpi_name, media, "CLIENT", str(int(client_id)), captured_at)

    if "id_part" in grupo.columns:
        for part_id, g in grupo.groupby("id_part"):
            media = round(g[coluna_valor].mean(), 2)
            insert_kpi_record(kpi_name, media, "PART", str(int(part_id)), captured_at)

    # LAB
    media_lab = round(grupo[coluna_valor].mean(), 2)
    insert_kpi_record(kpi_name, media_lab, "LAB", None, captured_at)

# ===================== KPI TAT =====================

def processar_tat():
    """Calcula e insere os registros do KPI TAT."""
    ultima_captura = get_last_capture("TAT")

    df = pd.read_sql("SELECT * FROM repairs", engine)
    df["resolved_at"] = pd.to_datetime(df["resolved_at"])
    df["submit_date"] = pd.to_datetime(df["submit_date"])
    df = df[df["resolved_at"].notna() & (df["resolved_at"] > ultima_captura)]

    if df.empty:
        print("Nenhum novo reparo para calcular TAT.")
        return

    df["tat"] = (df["resolved_at"] - df["submit_date"]).dt.total_seconds() / 3600

    # Agrupar por mês se necessário
    if (df["resolved_at"].max() - df["resolved_at"].min()).days > 31:
        df["mes"] = df["resolved_at"].dt.to_period("M")
        grupos = df.groupby("mes")
    else:
        grupos = [("UNICO", df)]

    for periodo, grupo in grupos:
        captured = (
            grupo["resolved_at"].max().strftime("%Y-%W-%d-00-00-00")
            if periodo != "UNICO"
            else datetime.now().strftime("%Y-%W-%d-00-00-00")
        )
        registrar_kpis_por_grupo(grupo, "TAT", "tat", captured)

    print("TAT processado com sucesso.")

# ===================== KPI RTR =====================

def processar_rtr():
    """Calcula e insere os registros do KPI RTR."""
    ultima_captura = get_last_capture("RTR")

    df = pd.read_sql("""
    SELECT id_client, id_part, resolved_at, num_tests, last_updated
    FROM repairs
    WHERE status = 'Concluído' AND resolved_at > %(last)s
    """, con=engine, params={"last": ultima_captura})

    df["resolved_at"] = pd.to_datetime(df["resolved_at"])
    df = df[df["num_tests"].notna() & (df["num_tests"] > 0)]

    if df.empty:
        print("Nenhum novo reparo para calcular RTR.")
        return

    if (df["resolved_at"].max() - df["resolved_at"].min()).days > 31:
        df["mes"] = df["resolved_at"].dt.to_period("M")
        grupos = df.groupby("mes")
    else:
        grupos = [("UNICO", df)]

    for periodo, grupo in grupos:
        captured = (
            grupo["resolved_at"].max().strftime("%Y-%W-%d-00-00-00")
            if periodo != "UNICO"
            else datetime.now().strftime("%Y-%W-%d-00-00-00")
        )
        registrar_kpis_por_grupo(grupo, "RTR", "num_tests", captured)

    print("RTR processado com sucesso.")

# ===================== MAIN =====================

def main():
    processar_tat()
    processar_rtr()
    # processar_fpy()
    # processar_mttr()
    # ...

if __name__ == "__main__":
    main()
