-- db/init_tables.sql

CREATE TABLE IF NOT EXISTS clients (
    id_client   SERIAL PRIMARY KEY,
    name_client VARCHAR(100) NOT NULL,
    contact     VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS parts (
    id_part     SERIAL PRIMARY KEY,
    num_serie   VARCHAR(30) NOT NULL UNIQUE,
    model       VARCHAR(300) NOT NULL,
    machine     VARCHAR(100),
    sid         VARCHAR(50),
    id_client   INT
                REFERENCES clients(id_client),
    description VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS repairs (
    id_repair    SERIAL PRIMARY KEY,
    id_part      INT
                 REFERENCES parts(id_part),
    id_client    INT
                 REFERENCES clients(id_client),
    id_monday    VARCHAR(30),
    proposal_no  VARCHAR(30),
    priority     VARCHAR(20),
    status       VARCHAR(50),
    submit_date  DATE,
    resolved_at  DATE,
    mttr         TIME,
    owner        VARCHAR(100),
    num_tests    INT,
    num_returns  INT,
    testing      VARCHAR(100),
    purchasing   VARCHAR(100),
    printing     VARCHAR(100),
    last_updated TIMESTAMP
);

CREATE TABLE IF NOT EXISTS kpi_records (
    id_kpi_record SERIAL PRIMARY KEY,
    kpi_name      VARCHAR(50)  NOT NULL,
    kpi_value     REAL         NOT NULL,
    referente     VARCHAR(150) NOT NULL,
    referente_id  VARCHAR(100),
    periodicity   VARCHAR(100) NOT NULL,
    captured_at   VARCHAR(100) NOT NULL
);
