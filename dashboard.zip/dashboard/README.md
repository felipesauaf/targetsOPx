# dashboard
dashboard-kpis
docker compose up --build -d