from flask import Flask, render_template_string
import matplotlib.pyplot as plt
import pandas as pd
import io
import base64

app = Flask(__name__)

# Carregar os dados do arquivo Excel
def carregar_dados():
    df = pd.read_excel('kpis.xlsx', skiprows=1)
    print("Colunas encontradas:", df.columns.tolist())
    df.columns = [str(col) for col in df.columns]
    ano_col = next((col for col in df.columns if 'Ano' in col), None)
    entry_col = next((col for col in df.columns if 'Num_entries' in col), None)
    if not ano_col or not entry_col:
        raise ValueError(f"Colunas 'Ano' ou 'Num_entries' não encontradas no arquivo. Colunas disponíveis: {df.columns.tolist()}")
    df = df[[ano_col, entry_col]]
    df.columns = ['Ano', 'Num_entries']
    df = df.dropna()
    df['Ano'] = df['Ano'].astype(int)
    df['Num_entries'] = df['Num_entries'].astype(int)
    return df

TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>OPX Lab - Gráfico de Dispersão</title>
</head>
<body style="background-color:black; color:white; text-align:center;">
    <h1 style="color:yellow;">OPX Lab - Gráfico de Dispersão Entradas por Ano</h1>
    <img src="data:image/png;base64,{{ plot_data }}">
</body>
</html>
"""

@app.route('/')
def scatter_plot():
    df = carregar_dados()
    anos = df['Ano'].tolist()
    entradas = df['Num_entries'].tolist()
    
    fig, ax = plt.subplots()
    ax.scatter(anos, entradas, color='yellow')
    ax.set_facecolor('black')
    ax.set_title("Entradas por Ano", color='yellow')
    ax.set_xlabel("Ano", color='white')
    ax.set_ylabel("Número de Entradas", color='white')
    ax.tick_params(axis='x', colors='white')
    ax.tick_params(axis='y', colors='white')
    
    fig.patch.set_facecolor('black')
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight', facecolor=fig.get_facecolor())
    buf.seek(0)
    plot_data = base64.b64encode(buf.getvalue()).decode()
    plt.close(fig)
    
    return render_template_string(TEMPLATE, plot_data=plot_data)

if __name__ == '__main__':
    app.run(host='::', port=5000)

