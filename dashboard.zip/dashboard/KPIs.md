Índices 

- TR (Throughput Rate)                           ---- LAB                                     -----   1ª etapa
- Turnaround Time (TAT)                          ---- LAB              + PEÇA + CLIENTE       -----   1ª etapa
- Repeat Testing Rate (RTR)                      ---- LAB + INDIVIDUAL + PEÇA                 -----   1ª etapa   ***IMPORTANTE
- Capacity                                       ---- LAB + INDIVIDUAL + PEÇA                 -----   1ª etapa
- First-Pass Yield (FPY)                         ---- LAB*+ INDIVIDUAL                        -----   1ª etapa
- Repair Efficiency (RE)                         ---- LAB + INDIVIDUAL*+ PEÇA                 -----   1ª etapa
- MTBF                                           ---- LAB + INDIVIDUAL + PEÇA + CLIENTE       -----   1ª etapa

- Hold                                           ---- LAB                                     -----   2ª etapa   #
- Conformidade                                   ---- LAB + INDIVIDUAL + PEÇA + CLIENTE       -----   2ª etapa   ***IMPORTANTE
- Time LAB (TAT - Timers Monday)                 ---- LAB + INDIVIDUAL + PEÇA + CLIENTE       -----   2ª etapa
- Non repair                                     ---- LAB                                     -----   2ª etapa
- Peças por status                               ---- LAB                                     -----   2ª etapa
- Tempo médio em cada etapa                      ---- LAB                                     -----   2ª etapa
- MTTR                                           ---- LAB + INDIVIDUAL + PEÇA + CLIENTE       -----   2ª etapa


ENTRADA
PAUSADO
REPARANDO
EM TESTE
CONCLUIDOS
EMPRÉSTIMO
ESTOQUE
HOLD
CATALOGACAO
REFERENCIAS
PROCEDI
COMPRAS

A cada 10 minutos
    Por reparo - cada novo concluído
        - Turnaround Time (TAT)                          ---- LAB              + PEÇA + CLIENTE       -----   1ª etapa
        - Repeat Testing Rate (RTR)                      ---- LAB + INDIVIDUAL + PEÇA                 -----   1ª etapa   ***IMPORTANTE
        - First-Pass Yield (FPY)                         ---- LAB*+ INDIVIDUAL                        -----   1ª etapa
        - MTTR                                           ---- LAB + INDIVIDUAL + PEÇA + CLIENTE       -----   2ª etapa
        - Non repair (necessário nova coluna Monday)     ---- LAB                                     -----   2ª etapa
        - Time LAB (TAT - Timers Monday)                 ---- LAB + INDIVIDUAL + PEÇA + CLIENTE       -----   2ª etapa

    Tempo real
        - Peças por status                               ---- LAB                                     -----   2ª etapa
        - Hold                                           ---- LAB                                     -----   2ª etapa   #


Semanais Ou Data Personalizada (inseridos a cada semana)
- TR (Throughput Rate)                           ---- LAB                                     -----   1ª etapa
- Capacity                                       ---- LAB + INDIVIDUAL + PEÇA                 -----   1ª etapa
- Repair Efficiency (RE)                         ---- LAB + INDIVIDUAL*+ PEÇA                 -----   1ª etapa
- MTBF                                           ---- LAB + INDIVIDUAL + PEÇA + CLIENTE       -----   1ª etapa
- Conformidade                                   ---- LAB + INDIVIDUAL + PEÇA + CLIENTE       -----   2ª etapa   ***IMPORTANTE
- Tempo médio em cada etapa                      ---- LAB                                     -----   2ª etapa
